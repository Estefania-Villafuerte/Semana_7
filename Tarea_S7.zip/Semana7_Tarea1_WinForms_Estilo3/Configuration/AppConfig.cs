using System.Text.Json;

namespace MonitoreoAmbiental.WinForms.Configuration;

public sealed class AppConfig
{
    public DatabaseOptions Database { get; init; } = new();

    public static AppConfig Load()
    {
        var path = Path.Combine(AppContext.BaseDirectory, "appsettings.json");
        if (!File.Exists(path))
        {
            throw new FileNotFoundException("No se encontro appsettings.json.", path);
        }

        var json = File.ReadAllText(path);
        return JsonSerializer.Deserialize<AppConfig>(json, new JsonSerializerOptions
        {
            PropertyNameCaseInsensitive = true
        }) ?? throw new InvalidOperationException("La configuracion no es valida.");
    }
}

public sealed class DatabaseOptions
{
    public string Server { get; init; } = "127.0.0.1";
    public uint Port { get; init; } = 3306;
    public string Database { get; init; } = "sensores_puyo_control";
    public string User { get; init; } = "root";
    public string Password { get; init; } = "root";
}
