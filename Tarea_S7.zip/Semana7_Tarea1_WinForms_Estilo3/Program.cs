using MonitoreoAmbiental.WinForms.Configuration;
using MonitoreoAmbiental.WinForms.Data;
using MonitoreoAmbiental.WinForms.Forms;
using MonitoreoAmbiental.WinForms.Services;

namespace MonitoreoAmbiental.WinForms;

static class Program
{
    [STAThread]
    static void Main()
    {
        ApplicationConfiguration.Initialize();
        try
        {
            var config = AppConfig.Load();
            var connectionFactory = new DbConnectionFactory(config.Database);
            new DatabaseInitializer(connectionFactory).InitializeAsync().GetAwaiter().GetResult();
            Application.Run(new Form1(new ServiceContainer(connectionFactory)));
        }
        catch (Exception ex)
        {
            MessageBox.Show(
                "No fue posible iniciar la aplicacion. Verifique que MySQL este encendido en MAMP y revise appsettings.json.\n\n" + ex.Message,
                "Conexion con MySQL",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
        }
    }
}
