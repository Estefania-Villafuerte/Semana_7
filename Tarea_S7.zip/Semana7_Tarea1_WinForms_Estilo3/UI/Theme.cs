namespace MonitoreoAmbiental.WinForms.UI;

public static class Theme
{
    public static readonly Color Background = Color.FromArgb(247, 247, 248);
    public static readonly Color Surface = Color.White;
    public static readonly Color Sidebar = Color.FromArgb(39, 40, 44);
    public static readonly Color SidebarHover = Color.FromArgb(65, 66, 71);
    public static readonly Color Primary = Color.FromArgb(184, 48, 75);
    public static readonly Color PrimaryDark = Color.FromArgb(140, 33, 54);
    public static readonly Color Warning = Color.FromArgb(224, 160, 40);
    public static readonly Color Danger = Color.FromArgb(164, 41, 50);
    public static readonly Color Text = Color.FromArgb(39, 40, 44);
    public static readonly Color Muted = Color.FromArgb(108, 108, 115);
    public static readonly Color Border = Color.FromArgb(222, 222, 226);
    public static readonly Color Secondary = Color.FromArgb(0, 132, 131);

    public const string IconDashboard = "\u25A6";
    public const string IconUsers = "\u2637";
    public const string IconDevice = "\u25A3";
    public const string IconMeasurement = "\u2103";
    public const string IconAudit = "\u26A0";
    public const string IconLogout = "\u2715";
    public const string IconAdd = "+";
    public const string IconEdit = "\u270E";
    public const string IconDelete = "\u2715";
    public const string IconRefresh = "\u21BB";
    public const string IconSearch = "\u2315";

    public static Button CreateCommandButton(string text, string icon, Color? backColor = null)
    {
        var color = backColor ?? Primary;
        var button = new Button
        {
            AutoSize = false,
            Height = 38,
            Width = 116,
            Text = $"{icon}  {text}",
            Font = new Font("Segoe UI", 9.5f, FontStyle.Bold),
            ForeColor = Color.White,
            BackColor = color,
            FlatStyle = FlatStyle.Flat,
            Cursor = Cursors.Hand,
            Margin = new Padding(0, 0, 8, 0)
        };
        button.FlatAppearance.BorderSize = 0;
        button.FlatAppearance.MouseOverBackColor = color == Danger ? Color.FromArgb(132, 29, 37) : PrimaryDark;
        return button;
    }

    public static void StyleGrid(DataGridView grid)
    {
        grid.BackgroundColor = Surface;
        grid.BorderStyle = BorderStyle.None;
        grid.CellBorderStyle = DataGridViewCellBorderStyle.Single;
        grid.GridColor = Border;
        grid.RowHeadersVisible = false;
        grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        grid.MultiSelect = false;
        grid.ReadOnly = true;
        grid.AllowUserToAddRows = false;
        grid.AllowUserToDeleteRows = false;
        grid.AllowUserToResizeRows = false;
        grid.AutoGenerateColumns = false;
        grid.RowTemplate.Height = 40;
        grid.ColumnHeadersHeight = 43;
        grid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
        grid.EnableHeadersVisualStyles = false;
        grid.ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle
        {
            BackColor = Color.FromArgb(245, 229, 233),
            ForeColor = PrimaryDark,
            Font = new Font("Segoe UI", 9.5f, FontStyle.Bold),
            Alignment = DataGridViewContentAlignment.MiddleLeft,
            Padding = new Padding(7, 0, 7, 0)
        };
        grid.DefaultCellStyle = new DataGridViewCellStyle
        {
            BackColor = Surface,
            ForeColor = Text,
            SelectionBackColor = Color.FromArgb(215, 239, 238),
            SelectionForeColor = Text,
            Font = new Font("Segoe UI", 9.5f),
            Padding = new Padding(7, 0, 7, 0)
        };
        grid.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(250, 250, 251);
    }

    public static DataGridViewTextBoxColumn TextColumn(string header, string property, int fillWeight = 100) => new()
    {
        HeaderText = header,
        DataPropertyName = property,
        AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill,
        FillWeight = fillWeight,
        SortMode = DataGridViewColumnSortMode.Automatic
    };
}

public static class UiMessages
{
    public static void Error(Exception ex)
    {
        var message = ex.Message;
        if (ex is MySqlConnector.MySqlException mysql && mysql.Number == 1062)
            message = "Ya existe un registro con ese codigo o nombre de usuario.";
        if (ex is MySqlConnector.MySqlException mysqlFk && mysqlFk.Number == 1451)
            message = "El registro no puede eliminarse porque tiene mediciones relacionadas.";
        MessageBox.Show(message, "No se pudo completar", MessageBoxButtons.OK, MessageBoxIcon.Warning);
    }
}
