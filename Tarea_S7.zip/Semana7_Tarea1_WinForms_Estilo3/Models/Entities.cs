namespace MonitoreoAmbiental.WinForms.Models;

public static class Roles
{
    public const string Admin = "Admin";
    public const string Operador = "Operador";
    public const string Consulta = "Consulta";

    public static readonly string[] All = [Admin, Operador, Consulta];
}

public sealed class User
{
    public int Id { get; set; }
    public string Username { get; set; } = string.Empty;
    public string FullName { get; set; } = string.Empty;
    public string Role { get; set; } = Roles.Consulta;
    public bool IsActive { get; set; } = true;
    public DateTime CreatedAt { get; set; }
}

public sealed class Device
{
    public int Id { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string Location { get; set; } = string.Empty;
    public string SensorType { get; set; } = "DHT11";
    public bool IsActive { get; set; } = true;
    public DateTime CreatedAt { get; set; }
}

public sealed class Measurement
{
    public int Id { get; set; }
    public int DeviceId { get; set; }
    public string DeviceName { get; set; } = string.Empty;
    public decimal Temperature { get; set; }
    public decimal Humidity { get; set; }
    public DateTime MeasuredAt { get; set; } = DateTime.Now;
    public string Notes { get; set; } = string.Empty;
}

public sealed class AccessLog
{
    public long Id { get; set; }
    public string Username { get; set; } = string.Empty;
    public string Role { get; set; } = string.Empty;
    public string Resource { get; set; } = string.Empty;
    public string Detail { get; set; } = string.Empty;
    public DateTime OccurredAt { get; set; }
}

public sealed class DashboardSummary
{
    public int Users { get; init; }
    public int Devices { get; init; }
    public int Measurements { get; init; }
    public int DeniedAccesses { get; init; }
}
