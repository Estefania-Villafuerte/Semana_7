CREATE DATABASE IF NOT EXISTS sensores_puyo_control
    CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE sensores_puyo_control;

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password_hash CHAR(64) NOT NULL,
    full_name VARCHAR(120) NOT NULL,
    role ENUM('Admin','Operador','Consulta') NOT NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS devices (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(30) NOT NULL UNIQUE,
    name VARCHAR(100) NOT NULL,
    location VARCHAR(150) NOT NULL,
    sensor_type VARCHAR(50) NOT NULL DEFAULT 'DHT11',
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS measurements (
    id INT AUTO_INCREMENT PRIMARY KEY,
    device_id INT NOT NULL,
    temperature DECIMAL(5,2) NOT NULL,
    humidity DECIMAL(5,2) NOT NULL,
    measured_at DATETIME NOT NULL,
    notes VARCHAR(250) NULL,
    CONSTRAINT fk_measurements_device FOREIGN KEY (device_id)
        REFERENCES devices(id) ON UPDATE CASCADE ON DELETE RESTRICT,
    INDEX ix_measurements_measured_at (measured_at)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS access_logs (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,
    username VARCHAR(50) NOT NULL,
    role VARCHAR(30) NOT NULL,
    resource VARCHAR(100) NOT NULL,
    detail VARCHAR(250) NOT NULL,
    occurred_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX ix_access_logs_occurred_at (occurred_at)
) ENGINE=InnoDB;

INSERT INTO users (username, password_hash, full_name, role, is_active)
VALUES
    ('admin', SHA2('Admin123*', 256), 'Administrador del sistema', 'Admin', 1),
    ('operador', SHA2('Opera123*', 256), 'Operador ambiental', 'Operador', 1),
    ('consulta', SHA2('Consulta123*', 256), 'Usuario de consulta', 'Consulta', 1)
ON DUPLICATE KEY UPDATE username = VALUES(username);

INSERT INTO devices (code, name, location, sensor_type, is_active)
VALUES
    ('PUYO-001', 'Estacion centro', 'Centro de Puyo', 'DHT11', 1),
    ('PUYO-002', 'Estacion universidad', 'Campus universitario', 'DHT22', 1)
ON DUPLICATE KEY UPDATE code = VALUES(code);

INSERT INTO measurements (device_id, temperature, humidity, measured_at, notes)
SELECT d.id, 24.50, 86.20, NOW(), 'Dato inicial de demostracion'
FROM devices d
WHERE d.code = 'PUYO-001'
  AND NOT EXISTS (SELECT 1 FROM measurements);
