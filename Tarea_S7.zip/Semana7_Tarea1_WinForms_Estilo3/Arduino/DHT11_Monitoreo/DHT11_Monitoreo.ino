#include <DHT.h>

#define DHT_PIN 2
#define DHT_TYPE DHT11

DHT sensor(DHT_PIN, DHT_TYPE);

void setup() {
  Serial.begin(9600);
  sensor.begin();
}

void loop() {
  float humidity = sensor.readHumidity();
  float temperature = sensor.readTemperature();

  if (isnan(humidity) || isnan(temperature)) {
    Serial.println("ERROR: no se pudo leer el sensor DHT11");
  } else {
    Serial.print("TEMP:");
    Serial.print(temperature, 2);
    Serial.print(";HUM:");
    Serial.println(humidity, 2);
  }

  delay(2000);
}
