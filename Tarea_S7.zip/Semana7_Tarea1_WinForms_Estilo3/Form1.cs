using MonitoreoAmbiental.WinForms.Services;

namespace MonitoreoAmbiental.WinForms.Forms;

public partial class Form1 : Form
{
    private ServiceContainer? _services;

    public Form1()
    {
        InitializeComponent();
    }

    public Form1(ServiceContainer services) : this()
    {
        _services = services;
    }

    private async void btnIngresar_Click(object sender, EventArgs e)
    {
        if (_services is null) return;

        try
        {
            btnIngresar.Enabled = false;
            lblEstado.ForeColor = Color.DimGray;
            lblEstado.Text = "Validando credenciales...";
            var user = await _services.Authentication.LoginAsync(txtUsuario.Text, txtClave.Text);
            if (user is null)
            {
                lblEstado.ForeColor = Color.Firebrick;
                lblEstado.Text = "Usuario o contrasena incorrectos.";
                return;
            }

            lblEstado.Text = string.Empty;
            Hide();
            using var main = new MainForm(user, _services);
            main.ShowDialog(this);
            Show();
            txtClave.SelectAll();
            txtClave.Focus();
        }
        catch (Exception ex)
        {
            lblEstado.ForeColor = Color.Firebrick;
            lblEstado.Text = ex.Message;
        }
        finally
        {
            btnIngresar.Enabled = true;
        }
    }

    private void Form1_Shown(object sender, EventArgs e)
    {
        txtUsuario.Focus();
    }
}
