using MonitoreoAmbiental.WinForms.Models;
using MySqlConnector;

namespace MonitoreoAmbiental.WinForms.Data;

public sealed class UserRepository(DbConnectionFactory factory)
{
    public async Task<User?> AuthenticateAsync(string username, string password)
    {
        const string sql = """
            SELECT id, username, full_name, role, is_active, created_at
            FROM users
            WHERE username = @username
              AND password_hash = SHA2(@password, 256)
              AND is_active = 1;
            """;

        await using var connection = factory.Create();
        await connection.OpenAsync();
        await using var command = new MySqlCommand(sql, connection);
        command.Parameters.AddWithValue("@username", username);
        command.Parameters.AddWithValue("@password", password);
        await using var reader = await command.ExecuteReaderAsync();
        return await reader.ReadAsync() ? ReadUser(reader) : null;
    }

    public async Task<List<User>> GetAllAsync(string search = "")
    {
        const string sql = """
            SELECT id, username, full_name, role, is_active, created_at
            FROM users
            WHERE @search = '' OR username LIKE @pattern OR full_name LIKE @pattern OR role LIKE @pattern
            ORDER BY full_name;
            """;
        var result = new List<User>();
        await using var connection = factory.Create();
        await connection.OpenAsync();
        await using var command = new MySqlCommand(sql, connection);
        command.Parameters.AddWithValue("@search", search);
        command.Parameters.AddWithValue("@pattern", $"%{search}%");
        await using var reader = await command.ExecuteReaderAsync();
        while (await reader.ReadAsync()) result.Add(ReadUser(reader));
        return result;
    }

    public async Task<int> CreateAsync(User user, string password)
    {
        const string sql = """
            INSERT INTO users (username, password_hash, full_name, role, is_active)
            VALUES (@username, SHA2(@password, 256), @fullName, @role, @active);
            SELECT LAST_INSERT_ID();
            """;
        await using var connection = factory.Create();
        await connection.OpenAsync();
        await using var command = new MySqlCommand(sql, connection);
        AddUserParameters(command, user);
        command.Parameters.AddWithValue("@password", password);
        return Convert.ToInt32(await command.ExecuteScalarAsync());
    }

    public async Task UpdateAsync(User user, string? password)
    {
        var sql = """
            UPDATE users
            SET username = @username, full_name = @fullName, role = @role, is_active = @active
            """;
        if (!string.IsNullOrWhiteSpace(password)) sql += ", password_hash = SHA2(@password, 256)";
        sql += " WHERE id = @id;";

        await using var connection = factory.Create();
        await connection.OpenAsync();
        await using var command = new MySqlCommand(sql, connection);
        AddUserParameters(command, user);
        command.Parameters.AddWithValue("@id", user.Id);
        if (!string.IsNullOrWhiteSpace(password)) command.Parameters.AddWithValue("@password", password);
        await command.ExecuteNonQueryAsync();
    }

    public async Task DeleteAsync(int id)
    {
        await ExecuteAsync("DELETE FROM users WHERE id = @id;", id);
    }

    public Task<int> CountAsync() => ScalarIntAsync("SELECT COUNT(*) FROM users;");

    private async Task ExecuteAsync(string sql, int id)
    {
        await using var connection = factory.Create();
        await connection.OpenAsync();
        await using var command = new MySqlCommand(sql, connection);
        command.Parameters.AddWithValue("@id", id);
        await command.ExecuteNonQueryAsync();
    }

    private async Task<int> ScalarIntAsync(string sql)
    {
        await using var connection = factory.Create();
        await connection.OpenAsync();
        await using var command = new MySqlCommand(sql, connection);
        return Convert.ToInt32(await command.ExecuteScalarAsync());
    }

    private static User ReadUser(MySqlDataReader reader) => new()
    {
        Id = reader.GetInt32("id"),
        Username = reader.GetString("username"),
        FullName = reader.GetString("full_name"),
        Role = reader.GetString("role"),
        IsActive = reader.GetBoolean("is_active"),
        CreatedAt = reader.GetDateTime("created_at")
    };

    private static void AddUserParameters(MySqlCommand command, User user)
    {
        command.Parameters.AddWithValue("@username", user.Username);
        command.Parameters.AddWithValue("@fullName", user.FullName);
        command.Parameters.AddWithValue("@role", user.Role);
        command.Parameters.AddWithValue("@active", user.IsActive);
    }
}

public sealed class DeviceRepository(DbConnectionFactory factory)
{
    public async Task<List<Device>> GetAllAsync(string search = "")
    {
        const string sql = """
            SELECT id, code, name, location, sensor_type, is_active, created_at
            FROM devices
            WHERE @search = '' OR code LIKE @pattern OR name LIKE @pattern OR location LIKE @pattern
            ORDER BY name;
            """;
        var result = new List<Device>();
        await using var connection = factory.Create();
        await connection.OpenAsync();
        await using var command = new MySqlCommand(sql, connection);
        command.Parameters.AddWithValue("@search", search);
        command.Parameters.AddWithValue("@pattern", $"%{search}%");
        await using var reader = await command.ExecuteReaderAsync();
        while (await reader.ReadAsync())
        {
            result.Add(new Device
            {
                Id = reader.GetInt32("id"), Code = reader.GetString("code"), Name = reader.GetString("name"),
                Location = reader.GetString("location"), SensorType = reader.GetString("sensor_type"),
                IsActive = reader.GetBoolean("is_active"), CreatedAt = reader.GetDateTime("created_at")
            });
        }
        return result;
    }

    public async Task<int> CreateAsync(Device device)
    {
        const string sql = """
            INSERT INTO devices (code, name, location, sensor_type, is_active)
            VALUES (@code, @name, @location, @sensorType, @active);
            SELECT LAST_INSERT_ID();
            """;
        return await SaveAsync(sql, device);
    }

    public async Task UpdateAsync(Device device)
    {
        const string sql = """
            UPDATE devices SET code=@code, name=@name, location=@location,
                sensor_type=@sensorType, is_active=@active WHERE id=@id;
            """;
        await SaveAsync(sql, device);
    }

    public async Task DeleteAsync(int id)
    {
        await using var connection = factory.Create();
        await connection.OpenAsync();
        await using var command = new MySqlCommand("DELETE FROM devices WHERE id=@id;", connection);
        command.Parameters.AddWithValue("@id", id);
        await command.ExecuteNonQueryAsync();
    }

    public Task<int> CountAsync() => CountTableAsync(factory, "devices");

    private async Task<int> SaveAsync(string sql, Device device)
    {
        await using var connection = factory.Create();
        await connection.OpenAsync();
        await using var command = new MySqlCommand(sql, connection);
        command.Parameters.AddWithValue("@id", device.Id);
        command.Parameters.AddWithValue("@code", device.Code);
        command.Parameters.AddWithValue("@name", device.Name);
        command.Parameters.AddWithValue("@location", device.Location);
        command.Parameters.AddWithValue("@sensorType", device.SensorType);
        command.Parameters.AddWithValue("@active", device.IsActive);
        var value = await command.ExecuteScalarAsync();
        return value is null ? device.Id : Convert.ToInt32(value);
    }

    internal static async Task<int> CountTableAsync(DbConnectionFactory factory, string table)
    {
        await using var connection = factory.Create();
        await connection.OpenAsync();
        await using var command = new MySqlCommand($"SELECT COUNT(*) FROM `{table}`;", connection);
        return Convert.ToInt32(await command.ExecuteScalarAsync());
    }
}

public sealed class MeasurementRepository(DbConnectionFactory factory)
{
    public async Task<List<Measurement>> GetAllAsync(string search = "")
    {
        const string sql = """
            SELECT m.id, m.device_id, d.name AS device_name, m.temperature, m.humidity,
                   m.measured_at, COALESCE(m.notes, '') AS notes
            FROM measurements m
            INNER JOIN devices d ON d.id = m.device_id
            WHERE @search = '' OR d.name LIKE @pattern OR d.code LIKE @pattern OR m.notes LIKE @pattern
            ORDER BY m.measured_at DESC;
            """;
        var result = new List<Measurement>();
        await using var connection = factory.Create();
        await connection.OpenAsync();
        await using var command = new MySqlCommand(sql, connection);
        command.Parameters.AddWithValue("@search", search);
        command.Parameters.AddWithValue("@pattern", $"%{search}%");
        await using var reader = await command.ExecuteReaderAsync();
        while (await reader.ReadAsync())
        {
            result.Add(new Measurement
            {
                Id = reader.GetInt32("id"), DeviceId = reader.GetInt32("device_id"),
                DeviceName = reader.GetString("device_name"), Temperature = reader.GetDecimal("temperature"),
                Humidity = reader.GetDecimal("humidity"), MeasuredAt = reader.GetDateTime("measured_at"),
                Notes = reader.GetString("notes")
            });
        }
        return result;
    }

    public Task<int> CreateAsync(Measurement measurement) => SaveAsync("""
        INSERT INTO measurements (device_id, temperature, humidity, measured_at, notes)
        VALUES (@deviceId, @temperature, @humidity, @measuredAt, @notes);
        SELECT LAST_INSERT_ID();
        """, measurement);

    public async Task UpdateAsync(Measurement measurement)
    {
        await SaveAsync("""
            UPDATE measurements SET device_id=@deviceId, temperature=@temperature, humidity=@humidity,
                measured_at=@measuredAt, notes=@notes WHERE id=@id;
            """, measurement);
    }

    public async Task DeleteAsync(int id)
    {
        await using var connection = factory.Create();
        await connection.OpenAsync();
        await using var command = new MySqlCommand("DELETE FROM measurements WHERE id=@id;", connection);
        command.Parameters.AddWithValue("@id", id);
        await command.ExecuteNonQueryAsync();
    }

    public Task<int> CountAsync() => DeviceRepository.CountTableAsync(factory, "measurements");

    private async Task<int> SaveAsync(string sql, Measurement measurement)
    {
        await using var connection = factory.Create();
        await connection.OpenAsync();
        await using var command = new MySqlCommand(sql, connection);
        command.Parameters.AddWithValue("@id", measurement.Id);
        command.Parameters.AddWithValue("@deviceId", measurement.DeviceId);
        command.Parameters.AddWithValue("@temperature", measurement.Temperature);
        command.Parameters.AddWithValue("@humidity", measurement.Humidity);
        command.Parameters.AddWithValue("@measuredAt", measurement.MeasuredAt);
        command.Parameters.AddWithValue("@notes", string.IsNullOrWhiteSpace(measurement.Notes) ? DBNull.Value : measurement.Notes);
        var value = await command.ExecuteScalarAsync();
        return value is null ? measurement.Id : Convert.ToInt32(value);
    }
}

public sealed class AccessLogRepository(DbConnectionFactory factory)
{
    public async Task AddDeniedAsync(User user, string resource, string detail)
    {
        const string sql = """
            INSERT INTO access_logs (user_id, username, role, resource, detail)
            VALUES (@userId, @username, @role, @resource, @detail);
            """;
        await using var connection = factory.Create();
        await connection.OpenAsync();
        await using var command = new MySqlCommand(sql, connection);
        command.Parameters.AddWithValue("@userId", user.Id);
        command.Parameters.AddWithValue("@username", user.Username);
        command.Parameters.AddWithValue("@role", user.Role);
        command.Parameters.AddWithValue("@resource", resource);
        command.Parameters.AddWithValue("@detail", detail);
        await command.ExecuteNonQueryAsync();
    }

    public async Task<List<AccessLog>> GetAllAsync()
    {
        const string sql = """
            SELECT id, username, role, resource, detail, occurred_at
            FROM access_logs ORDER BY occurred_at DESC LIMIT 500;
            """;
        var result = new List<AccessLog>();
        await using var connection = factory.Create();
        await connection.OpenAsync();
        await using var command = new MySqlCommand(sql, connection);
        await using var reader = await command.ExecuteReaderAsync();
        while (await reader.ReadAsync())
        {
            result.Add(new AccessLog
            {
                Id = reader.GetInt64("id"), Username = reader.GetString("username"),
                Role = reader.GetString("role"), Resource = reader.GetString("resource"),
                Detail = reader.GetString("detail"), OccurredAt = reader.GetDateTime("occurred_at")
            });
        }
        return result;
    }

    public Task<int> CountAsync() => DeviceRepository.CountTableAsync(factory, "access_logs");
}
