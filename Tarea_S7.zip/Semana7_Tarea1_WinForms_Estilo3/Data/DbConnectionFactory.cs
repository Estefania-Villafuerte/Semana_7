using MonitoreoAmbiental.WinForms.Configuration;
using MySqlConnector;

namespace MonitoreoAmbiental.WinForms.Data;

public sealed class DbConnectionFactory(DatabaseOptions options)
{
    public MySqlConnection Create(bool includeDatabase = true)
    {
        var builder = new MySqlConnectionStringBuilder
        {
            Server = options.Server,
            Port = options.Port,
            UserID = options.User,
            Password = options.Password,
            Database = includeDatabase ? options.Database : string.Empty,
            SslMode = MySqlSslMode.None,
            AllowPublicKeyRetrieval = true,
            ConnectionTimeout = 5,
            DefaultCommandTimeout = 15
        };

        return new MySqlConnection(builder.ConnectionString);
    }

    public string DatabaseName => options.Database;
}
