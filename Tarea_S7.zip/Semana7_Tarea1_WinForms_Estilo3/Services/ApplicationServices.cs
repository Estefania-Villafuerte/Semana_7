using MonitoreoAmbiental.WinForms.Data;
using MonitoreoAmbiental.WinForms.Models;

namespace MonitoreoAmbiental.WinForms.Services;

public sealed class AuthenticationService(UserRepository repository)
{
    public async Task<User?> LoginAsync(string username, string password)
    {
        if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password)) return null;
        return await repository.AuthenticateAsync(username.Trim(), password);
    }
}

public sealed class UserService(UserRepository repository)
{
    public Task<List<User>> GetAllAsync(string search = "") => repository.GetAllAsync(search.Trim());

    public async Task SaveAsync(User user, string? password)
    {
        if (string.IsNullOrWhiteSpace(user.Username)) throw new ArgumentException("El usuario es obligatorio.");
        if (string.IsNullOrWhiteSpace(user.FullName)) throw new ArgumentException("El nombre es obligatorio.");
        if (!Roles.All.Contains(user.Role)) throw new ArgumentException("El rol seleccionado no es valido.");
        if (user.Id == 0 && string.IsNullOrWhiteSpace(password)) throw new ArgumentException("La contrasena es obligatoria.");
        if (!string.IsNullOrWhiteSpace(password) && password.Length < 6) throw new ArgumentException("La contrasena debe tener al menos 6 caracteres.");

        if (user.Id == 0) await repository.CreateAsync(user, password!);
        else await repository.UpdateAsync(user, password);
    }

    public Task DeleteAsync(int id, int currentUserId)
    {
        if (id == currentUserId) throw new InvalidOperationException("No puede eliminar su propia cuenta mientras esta autenticado.");
        return repository.DeleteAsync(id);
    }
}

public sealed class DeviceService(DeviceRepository repository)
{
    public Task<List<Device>> GetAllAsync(string search = "") => repository.GetAllAsync(search.Trim());

    public async Task SaveAsync(Device device)
    {
        if (string.IsNullOrWhiteSpace(device.Code)) throw new ArgumentException("El codigo es obligatorio.");
        if (string.IsNullOrWhiteSpace(device.Name)) throw new ArgumentException("El nombre es obligatorio.");
        if (string.IsNullOrWhiteSpace(device.Location)) throw new ArgumentException("La ubicacion es obligatoria.");
        if (device.Id == 0) await repository.CreateAsync(device); else await repository.UpdateAsync(device);
    }

    public Task DeleteAsync(int id) => repository.DeleteAsync(id);
}

public sealed class MeasurementService(MeasurementRepository repository)
{
    public Task<List<Measurement>> GetAllAsync(string search = "") => repository.GetAllAsync(search.Trim());

    public async Task SaveAsync(Measurement measurement)
    {
        if (measurement.DeviceId <= 0) throw new ArgumentException("Seleccione un dispositivo.");
        if (measurement.Temperature is < -20 or > 60) throw new ArgumentException("La temperatura debe estar entre -20 y 60 C.");
        if (measurement.Humidity is < 0 or > 100) throw new ArgumentException("La humedad debe estar entre 0 y 100%.");
        if (measurement.Id == 0) await repository.CreateAsync(measurement); else await repository.UpdateAsync(measurement);
    }

    public Task DeleteAsync(int id) => repository.DeleteAsync(id);
}

public sealed class AuditService(AccessLogRepository repository)
{
    public Task LogDeniedAsync(User user, string resource, string detail) => repository.AddDeniedAsync(user, resource, detail);
    public Task<List<AccessLog>> GetAllAsync() => repository.GetAllAsync();
}

public sealed class DashboardService(
    UserRepository users,
    DeviceRepository devices,
    MeasurementRepository measurements,
    AccessLogRepository logs)
{
    public async Task<DashboardSummary> GetSummaryAsync()
    {
        var userCount = users.CountAsync();
        var deviceCount = devices.CountAsync();
        var measurementCount = measurements.CountAsync();
        var logCount = logs.CountAsync();
        await Task.WhenAll(userCount, deviceCount, measurementCount, logCount);
        return new DashboardSummary
        {
            Users = userCount.Result,
            Devices = deviceCount.Result,
            Measurements = measurementCount.Result,
            DeniedAccesses = logCount.Result
        };
    }
}
