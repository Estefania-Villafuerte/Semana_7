using MonitoreoAmbiental.WinForms.Data;
using MonitoreoAmbiental.WinForms.Models;

namespace MonitoreoAmbiental.WinForms.Services;

public interface IAuthorizationService
{
    bool CanAccess(string? allowedRoles, string currentRole);
    void ApplyPermissions(Control root, string currentRole);
    Task<bool> EnsureAccessAsync(User user, string allowedRoles, string resource, string detail);
}

public sealed class AuthorizationService(AuditService auditService) : IAuthorizationService
{
    public bool CanAccess(string? allowedRoles, string currentRole)
    {
        if (string.IsNullOrWhiteSpace(allowedRoles)) return true;
        return allowedRoles.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
            .Any(role => role.Equals(currentRole, StringComparison.OrdinalIgnoreCase));
    }

    public void ApplyPermissions(Control root, string currentRole)
    {
        ApplyToControl(root, currentRole);
        foreach (Control child in root.Controls) ApplyPermissions(child, currentRole);

        if (root is MenuStrip menu) ApplyToItems(menu.Items, currentRole);
        if (root is ToolStrip toolStrip) ApplyToItems(toolStrip.Items, currentRole);
    }

    public async Task<bool> EnsureAccessAsync(User user, string allowedRoles, string resource, string detail)
    {
        if (CanAccess(allowedRoles, user.Role)) return true;
        await auditService.LogDeniedAsync(user, resource, detail);
        return false;
    }

    private void ApplyToControl(Control control, string currentRole)
    {
        if (control.Tag is not string allowedRoles) return;
        var allowed = CanAccess(allowedRoles, currentRole);
        control.Enabled = allowed;
        control.TabStop = allowed;
    }

    private void ApplyToItems(ToolStripItemCollection items, string currentRole)
    {
        foreach (ToolStripItem item in items)
        {
            if (item.Tag is string roles) item.Enabled = CanAccess(roles, currentRole);
            if (item is ToolStripDropDownItem dropDown) ApplyToItems(dropDown.DropDownItems, currentRole);
        }
    }
}

public sealed class ServiceContainer(DbConnectionFactory factory)
{
    private readonly UserRepository _users = new(factory);
    private readonly DeviceRepository _devices = new(factory);
    private readonly MeasurementRepository _measurements = new(factory);
    private readonly AccessLogRepository _logs = new(factory);

    public AuthenticationService Authentication => new(_users);
    public UserService Users => new(_users);
    public DeviceService Devices => new(_devices);
    public MeasurementService Measurements => new(_measurements);
    public AuditService Audit => new(_logs);
    public DashboardService Dashboard => new(_users, _devices, _measurements, _logs);
    public IAuthorizationService Authorization => new AuthorizationService(Audit);
}
