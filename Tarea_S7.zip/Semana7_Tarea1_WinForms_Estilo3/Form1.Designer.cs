namespace MonitoreoAmbiental.WinForms.Forms;

partial class Form1
{
    private System.ComponentModel.IContainer components = null!;
    private Panel panelBanner = null!;
    private Label lblMarca = null!;
    private Label lblVariables = null!;
    private Label lblTitulo = null!;
    private Label lblUsuario = null!;
    private TextBox txtUsuario = null!;
    private Label lblClave = null!;
    private TextBox txtClave = null!;
    private Label lblAyuda = null!;
    private Button btnIngresar = null!;
    private Label lblEstado = null!;

    protected override void Dispose(bool disposing)
    {
        if (disposing) components?.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        components = new System.ComponentModel.Container();
        panelBanner = new Panel();
        lblMarca = new Label();
        lblVariables = new Label();
        lblTitulo = new Label();
        lblUsuario = new Label();
        txtUsuario = new TextBox();
        lblClave = new Label();
        txtClave = new TextBox();
        lblAyuda = new Label();
        btnIngresar = new Button();
        lblEstado = new Label();
        panelBanner.SuspendLayout();
        SuspendLayout();
        panelBanner.BackColor = Color.FromArgb(184, 48, 75);
        panelBanner.Controls.Add(lblMarca);
        panelBanner.Controls.Add(lblVariables);
        panelBanner.Dock = DockStyle.Top;
        panelBanner.Height = 185;
        lblMarca.AutoSize = true;
        lblMarca.Font = new Font("Segoe UI", 30F, FontStyle.Bold);
        lblMarca.ForeColor = Color.White;
        lblMarca.Location = new Point(64, 62);
        lblMarca.Text = "SENSOR PUYO";
        lblVariables.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        lblVariables.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
        lblVariables.ForeColor = Color.White;
        lblVariables.Location = new Point(730, 49);
        lblVariables.Size = new Size(170, 90);
        lblVariables.Text = "TEMPERATURA\n\nHUMEDAD";
        lblVariables.TextAlign = ContentAlignment.MiddleCenter;
        lblTitulo.AutoSize = true;
        lblTitulo.Font = new Font("Segoe UI", 17F, FontStyle.Bold);
        lblTitulo.Location = new Point(64, 224);
        lblTitulo.Text = "Acceso al control ambiental";
        lblUsuario.AutoSize = true;
        lblUsuario.Location = new Point(64, 286);
        lblUsuario.Text = "Usuario";
        txtUsuario.Location = new Point(64, 312);
        txtUsuario.Size = new Size(390, 25);
        txtUsuario.Text = "admin";
        lblClave.AutoSize = true;
        lblClave.Location = new Point(492, 286);
        lblClave.Text = "Contrasena";
        txtClave.Location = new Point(492, 312);
        txtClave.Size = new Size(390, 25);
        txtClave.Text = "Admin123*";
        txtClave.UseSystemPasswordChar = true;
        lblAyuda.AutoSize = true;
        lblAyuda.ForeColor = Color.DimGray;
        lblAyuda.Location = new Point(64, 371);
        lblAyuda.Text = "Cuentas de demostracion: admin, operador y consulta";
        btnIngresar.BackColor = Color.FromArgb(184, 48, 75);
        btnIngresar.FlatStyle = FlatStyle.Flat;
        btnIngresar.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
        btnIngresar.ForeColor = Color.White;
        btnIngresar.Location = new Point(64, 414);
        btnIngresar.Size = new Size(230, 44);
        btnIngresar.Text = "Entrar al sistema";
        btnIngresar.Click += btnIngresar_Click;
        lblEstado.AutoSize = true;
        lblEstado.ForeColor = Color.Firebrick;
        lblEstado.Location = new Point(64, 484);
        AcceptButton = btnIngresar;
        AutoScaleMode = AutoScaleMode.Font;
        BackColor = Color.White;
        ClientSize = new Size(960, 560);
        Controls.Add(lblTitulo);
        Controls.Add(lblUsuario);
        Controls.Add(txtUsuario);
        Controls.Add(lblClave);
        Controls.Add(txtClave);
        Controls.Add(lblAyuda);
        Controls.Add(btnIngresar);
        Controls.Add(lblEstado);
        Controls.Add(panelBanner);
        Font = new Font("Segoe UI", 10F);
        MinimumSize = new Size(880, 540);
        Name = "Form1";
        StartPosition = FormStartPosition.CenterScreen;
        Text = "Sensor Puyo - Identificacion";
        Shown += Form1_Shown;
        panelBanner.ResumeLayout(false);
        panelBanner.PerformLayout();
        ResumeLayout(false);
        PerformLayout();
    }
}
