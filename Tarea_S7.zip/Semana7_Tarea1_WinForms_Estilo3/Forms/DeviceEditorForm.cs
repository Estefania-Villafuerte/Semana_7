using System.ComponentModel;
using MonitoreoAmbiental.WinForms.Models;
using MonitoreoAmbiental.WinForms.Services;

namespace MonitoreoAmbiental.WinForms.Forms;

public partial class DeviceEditorForm : Form
{
    private DeviceService? _service;
    private User? _currentUser;
    private IAuthorizationService? _authorization;
    private int _selectedId;

    public DeviceEditorForm()
    {
        InitializeComponent();
        cboSensor.SelectedIndex = 0;
    }

    public DeviceEditorForm(DeviceService service, User currentUser, IAuthorizationService authorization) : this()
    {
        _service = service;
        _currentUser = currentUser;
        _authorization = authorization;
        authorization.ApplyPermissions(this, currentUser.Role);
    }

    private async void DeviceEditorForm_Load(object sender, EventArgs e) => await CargarAsync();

    private async Task CargarAsync()
    {
        if (_service is null) return;
        try
        {
            var data = await _service.GetAllAsync(txtBuscar.Text);
            dgvDispositivos.DataSource = new BindingList<Device>(data);
            lblRegistros.Text = $"{data.Count} registro(s)";
        }
        catch (Exception ex) { MostrarError(ex); }
    }

    private void dgvDispositivos_SelectionChanged(object sender, EventArgs e)
    {
        if (dgvDispositivos.CurrentRow?.DataBoundItem is not Device device) return;
        _selectedId = device.Id;
        txtCodigo.Text = device.Code;
        txtNombre.Text = device.Name;
        txtUbicacion.Text = device.Location;
        cboSensor.SelectedItem = device.SensorType;
        chkActivo.Checked = device.IsActive;
    }

    private void btnNuevo_Click(object sender, EventArgs e)
    {
        _selectedId = 0;
        txtCodigo.Clear();
        txtNombre.Clear();
        txtUbicacion.Clear();
        cboSensor.SelectedIndex = 0;
        chkActivo.Checked = true;
        txtCodigo.Focus();
    }

    private async void btnGuardar_Click(object sender, EventArgs e)
    {
        if (_service is null || _currentUser is null || _authorization is null) return;
        if (!await _authorization.EnsureAccessAsync(_currentUser, "Admin,Operador", "Dispositivos", "Crear o editar dispositivo")) return;
        try
        {
            await _service.SaveAsync(new Device
            {
                Id = _selectedId,
                Code = txtCodigo.Text.Trim().ToUpperInvariant(),
                Name = txtNombre.Text.Trim(),
                Location = txtUbicacion.Text.Trim(),
                SensorType = cboSensor.SelectedItem?.ToString() ?? "DHT11",
                IsActive = chkActivo.Checked
            });
            await CargarAsync();
            btnNuevo.PerformClick();
        }
        catch (Exception ex) { MostrarError(ex); }
    }

    private async void btnEliminar_Click(object sender, EventArgs e)
    {
        if (_service is null || _currentUser is null || _authorization is null || _selectedId == 0) return;
        if (!await _authorization.EnsureAccessAsync(_currentUser, "Admin,Operador", "Dispositivos", "Eliminar dispositivo")) return;
        if (MessageBox.Show("Desea eliminar el dispositivo seleccionado?", "Dispositivos", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
        try
        {
            await _service.DeleteAsync(_selectedId);
            await CargarAsync();
            btnNuevo.PerformClick();
        }
        catch (Exception ex) { MostrarError(ex); }
    }

    private async void btnBuscar_Click(object sender, EventArgs e) => await CargarAsync();

    private static void MostrarError(Exception ex)
    {
        MessageBox.Show(ex.Message, "Dispositivos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
    }
}
