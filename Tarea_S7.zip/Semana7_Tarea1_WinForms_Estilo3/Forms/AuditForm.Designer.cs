namespace MonitoreoAmbiental.WinForms.Forms;

partial class AuditForm
{
    private System.ComponentModel.IContainer components = null!;
    private Label lblTitulo = null!;
    private Button btnActualizar = null!;
    private DataGridView dgvAuditoria = null!;
    private Label lblRegistros = null!;

    protected override void Dispose(bool disposing)
    {
        if (disposing) components?.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        components = new System.ComponentModel.Container();
        lblTitulo = new Label();
        btnActualizar = new Button();
        dgvAuditoria = new DataGridView();
        lblRegistros = new Label();
        ((System.ComponentModel.ISupportInitialize)dgvAuditoria).BeginInit();
        SuspendLayout();
        lblTitulo.AutoSize = true;
        lblTitulo.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
        lblTitulo.Location = new Point(28, 24);
        lblTitulo.Text = "Registro de accesos denegados";
        btnActualizar.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        btnActualizar.BackColor = Color.FromArgb(0, 126, 112);
        btnActualizar.FlatStyle = FlatStyle.Flat;
        btnActualizar.ForeColor = Color.White;
        btnActualizar.Location = new Point(855, 24);
        btnActualizar.Size = new Size(120, 36);
        btnActualizar.Text = "Actualizar";
        btnActualizar.Click += btnActualizar_Click;
        dgvAuditoria.AllowUserToAddRows = false;
        dgvAuditoria.AllowUserToDeleteRows = false;
        dgvAuditoria.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
        dgvAuditoria.AutoGenerateColumns = false;
        dgvAuditoria.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        dgvAuditoria.BackgroundColor = Color.White;
        dgvAuditoria.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "OccurredAt", HeaderText = "Fecha" });
        dgvAuditoria.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Username", HeaderText = "Usuario" });
        dgvAuditoria.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Role", HeaderText = "Rol" });
        dgvAuditoria.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Resource", HeaderText = "Recurso" });
        dgvAuditoria.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Detail", HeaderText = "Detalle" });
        dgvAuditoria.Location = new Point(28, 82);
        dgvAuditoria.ReadOnly = true;
        dgvAuditoria.RowHeadersVisible = false;
        dgvAuditoria.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        dgvAuditoria.Size = new Size(947, 443);
        lblRegistros.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
        lblRegistros.AutoSize = true;
        lblRegistros.Location = new Point(28, 541);
        lblRegistros.Text = "0 registro(s)";
        AutoScaleMode = AutoScaleMode.Font;
        BackColor = Color.FromArgb(244, 247, 246);
        ClientSize = new Size(1004, 580);
        Controls.Add(lblTitulo);
        Controls.Add(btnActualizar);
        Controls.Add(dgvAuditoria);
        Controls.Add(lblRegistros);
        Font = new Font("Segoe UI", 10F);
        MinimumSize = new Size(900, 560);
        Name = "AuditForm";
        StartPosition = FormStartPosition.CenterParent;
        Text = "Auditoria";
        Load += AuditForm_Load;
        ((System.ComponentModel.ISupportInitialize)dgvAuditoria).EndInit();
        ResumeLayout(false);
        PerformLayout();
    }
}
