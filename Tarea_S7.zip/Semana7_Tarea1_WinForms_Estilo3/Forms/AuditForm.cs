using System.ComponentModel;
using MonitoreoAmbiental.WinForms.Models;
using MonitoreoAmbiental.WinForms.Services;

namespace MonitoreoAmbiental.WinForms.Forms;

public partial class AuditForm : Form
{
    private AuditService? _service;

    public AuditForm()
    {
        InitializeComponent();
    }

    public AuditForm(AuditService service) : this()
    {
        _service = service;
    }

    private async void AuditForm_Load(object sender, EventArgs e) => await CargarAsync();

    private async void btnActualizar_Click(object sender, EventArgs e) => await CargarAsync();

    private async Task CargarAsync()
    {
        if (_service is null) return;
        try
        {
            var data = await _service.GetAllAsync();
            dgvAuditoria.DataSource = new BindingList<AccessLog>(data);
            lblRegistros.Text = $"{data.Count} registro(s)";
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Auditoria", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }
}
