using MonitoreoAmbiental.WinForms.Models;
using MonitoreoAmbiental.WinForms.Services;

namespace MonitoreoAmbiental.WinForms.Forms;

public partial class MainForm : Form
{
    private User? _currentUser;
    private ServiceContainer? _services;

    public MainForm()
    {
        InitializeComponent();
    }

    public MainForm(User currentUser, ServiceContainer services) : this()
    {
        _currentUser = currentUser;
        _services = services;
        lblUsuario.Text = currentUser.FullName;
        lblRol.Text = currentUser.Role;
        services.Authorization.ApplyPermissions(this, currentUser.Role);
    }

    private async void MainForm_Load(object sender, EventArgs e)
    {
        await ActualizarResumenAsync();
    }

    private async Task ActualizarResumenAsync()
    {
        if (_services is null) return;
        try
        {
            var summary = await _services.Dashboard.GetSummaryAsync();
            lblCantidadUsuarios.Text = summary.Users.ToString();
            lblCantidadDispositivos.Text = summary.Devices.ToString();
            lblCantidadMediciones.Text = summary.Measurements.ToString();
            lblCantidadBloqueos.Text = summary.DeniedAccesses.ToString();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Resumen", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    private async void btnInicio_Click(object sender, EventArgs e)
    {
        lblTitulo.Text = "Panel principal";
        await ActualizarResumenAsync();
    }

    private void btnUsuarios_Click(object sender, EventArgs e)
    {
        if (_services is null || _currentUser is null) return;
        using var form = new UserEditorForm(_services.Users, _currentUser, _services.Authorization);
        form.ShowDialog(this);
    }

    private void btnDispositivos_Click(object sender, EventArgs e)
    {
        if (_services is null || _currentUser is null) return;
        using var form = new DeviceEditorForm(_services.Devices, _currentUser, _services.Authorization);
        form.ShowDialog(this);
    }

    private void btnMediciones_Click(object sender, EventArgs e)
    {
        if (_services is null || _currentUser is null) return;
        using var form = new MeasurementEditorForm(_services.Measurements, _services.Devices, _currentUser, _services.Authorization);
        form.ShowDialog(this);
    }

    private void btnAuditoria_Click(object sender, EventArgs e)
    {
        if (_services is null) return;
        using var form = new AuditForm(_services.Audit);
        form.ShowDialog(this);
    }

    private void btnCerrarSesion_Click(object sender, EventArgs e)
    {
        Close();
    }
}
