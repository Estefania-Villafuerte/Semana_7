using System.ComponentModel;
using MonitoreoAmbiental.WinForms.Models;
using MonitoreoAmbiental.WinForms.Services;

namespace MonitoreoAmbiental.WinForms.Forms;

public partial class UserEditorForm : Form
{
    private UserService? _service;
    private User? _currentUser;
    private IAuthorizationService? _authorization;
    private int _selectedId;

    public UserEditorForm()
    {
        InitializeComponent();
        cboRol.Items.AddRange(Roles.All);
        cboRol.SelectedIndex = 2;
    }

    public UserEditorForm(UserService service, User currentUser, IAuthorizationService authorization) : this()
    {
        _service = service;
        _currentUser = currentUser;
        _authorization = authorization;
        authorization.ApplyPermissions(this, currentUser.Role);
    }

    private async void UserEditorForm_Load(object sender, EventArgs e)
    {
        await CargarAsync();
    }

    private async Task CargarAsync()
    {
        if (_service is null) return;
        try
        {
            var data = await _service.GetAllAsync(txtBuscar.Text);
            dgvUsuarios.DataSource = new BindingList<User>(data);
            lblRegistros.Text = $"{data.Count} registro(s)";
        }
        catch (Exception ex) { MostrarError(ex); }
    }

    private void dgvUsuarios_SelectionChanged(object sender, EventArgs e)
    {
        if (dgvUsuarios.CurrentRow?.DataBoundItem is not User user) return;
        _selectedId = user.Id;
        txtUsuario.Text = user.Username;
        txtNombre.Text = user.FullName;
        cboRol.SelectedItem = user.Role;
        chkActivo.Checked = user.IsActive;
        txtClave.Clear();
    }

    private void btnNuevo_Click(object sender, EventArgs e)
    {
        _selectedId = 0;
        txtUsuario.Clear();
        txtNombre.Clear();
        txtClave.Clear();
        cboRol.SelectedIndex = 2;
        chkActivo.Checked = true;
        txtUsuario.Focus();
    }

    private async void btnGuardar_Click(object sender, EventArgs e)
    {
        if (_service is null || _currentUser is null || _authorization is null) return;
        if (!await _authorization.EnsureAccessAsync(_currentUser, Roles.Admin, "Usuarios", "Crear o editar usuario")) return;
        try
        {
            var user = new User
            {
                Id = _selectedId,
                Username = txtUsuario.Text.Trim(),
                FullName = txtNombre.Text.Trim(),
                Role = cboRol.SelectedItem?.ToString() ?? Roles.Consulta,
                IsActive = chkActivo.Checked
            };
            await _service.SaveAsync(user, string.IsNullOrWhiteSpace(txtClave.Text) ? null : txtClave.Text);
            await CargarAsync();
            btnNuevo.PerformClick();
        }
        catch (Exception ex) { MostrarError(ex); }
    }

    private async void btnEliminar_Click(object sender, EventArgs e)
    {
        if (_service is null || _currentUser is null || _authorization is null || _selectedId == 0) return;
        if (!await _authorization.EnsureAccessAsync(_currentUser, Roles.Admin, "Usuarios", "Eliminar usuario")) return;
        if (MessageBox.Show("Desea eliminar el usuario seleccionado?", "Usuarios", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
        try
        {
            await _service.DeleteAsync(_selectedId, _currentUser.Id);
            await CargarAsync();
            btnNuevo.PerformClick();
        }
        catch (Exception ex) { MostrarError(ex); }
    }

    private async void btnBuscar_Click(object sender, EventArgs e)
    {
        await CargarAsync();
    }

    private static void MostrarError(Exception ex)
    {
        MessageBox.Show(ex.Message, "Usuarios", MessageBoxButtons.OK, MessageBoxIcon.Warning);
    }
}
