using System.ComponentModel;
using MonitoreoAmbiental.WinForms.Models;
using MonitoreoAmbiental.WinForms.Services;

namespace MonitoreoAmbiental.WinForms.Forms;

public partial class MeasurementEditorForm : Form
{
    private MeasurementService? _service;
    private DeviceService? _devices;
    private User? _currentUser;
    private IAuthorizationService? _authorization;
    private int _selectedId;

    public MeasurementEditorForm()
    {
        InitializeComponent();
    }

    public MeasurementEditorForm(MeasurementService service, DeviceService devices, User currentUser, IAuthorizationService authorization) : this()
    {
        _service = service;
        _devices = devices;
        _currentUser = currentUser;
        _authorization = authorization;
        authorization.ApplyPermissions(this, currentUser.Role);
    }

    private async void MeasurementEditorForm_Load(object sender, EventArgs e)
    {
        if (_devices is null) return;
        try
        {
            var devices = await _devices.GetAllAsync();
            cboDispositivo.DisplayMember = nameof(Device.Name);
            cboDispositivo.ValueMember = nameof(Device.Id);
            cboDispositivo.DataSource = devices.Where(d => d.IsActive).ToList();
            await CargarAsync();
        }
        catch (Exception ex) { MostrarError(ex); }
    }

    private async Task CargarAsync()
    {
        if (_service is null) return;
        var data = await _service.GetAllAsync(txtBuscar.Text);
        dgvMediciones.DataSource = new BindingList<Measurement>(data);
        lblRegistros.Text = $"{data.Count} registro(s)";
    }

    private void dgvMediciones_SelectionChanged(object sender, EventArgs e)
    {
        if (dgvMediciones.CurrentRow?.DataBoundItem is not Measurement item) return;
        _selectedId = item.Id;
        cboDispositivo.SelectedValue = item.DeviceId;
        nudTemperatura.Value = Math.Clamp(item.Temperature, nudTemperatura.Minimum, nudTemperatura.Maximum);
        nudHumedad.Value = Math.Clamp(item.Humidity, nudHumedad.Minimum, nudHumedad.Maximum);
        dtpFecha.Value = item.MeasuredAt;
        txtObservaciones.Text = item.Notes;
    }

    private void btnNuevo_Click(object sender, EventArgs e)
    {
        _selectedId = 0;
        nudTemperatura.Value = 0;
        nudHumedad.Value = 0;
        dtpFecha.Value = DateTime.Now;
        txtObservaciones.Clear();
    }

    private async void btnGuardar_Click(object sender, EventArgs e)
    {
        if (_service is null || _currentUser is null || _authorization is null) return;
        if (!await _authorization.EnsureAccessAsync(_currentUser, "Admin,Operador", "Mediciones", "Crear o editar medicion")) return;
        try
        {
            await _service.SaveAsync(new Measurement
            {
                Id = _selectedId,
                DeviceId = cboDispositivo.SelectedValue is int id ? id : 0,
                Temperature = nudTemperatura.Value,
                Humidity = nudHumedad.Value,
                MeasuredAt = dtpFecha.Value,
                Notes = txtObservaciones.Text.Trim()
            });
            await CargarAsync();
            btnNuevo.PerformClick();
        }
        catch (Exception ex) { MostrarError(ex); }
    }

    private async void btnEliminar_Click(object sender, EventArgs e)
    {
        if (_service is null || _currentUser is null || _authorization is null || _selectedId == 0) return;
        if (!await _authorization.EnsureAccessAsync(_currentUser, Roles.Admin, "Mediciones", "Eliminar medicion")) return;
        if (MessageBox.Show("Desea eliminar la medicion seleccionada?", "Mediciones", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
        try
        {
            await _service.DeleteAsync(_selectedId);
            await CargarAsync();
            btnNuevo.PerformClick();
        }
        catch (Exception ex) { MostrarError(ex); }
    }

    private async void btnBuscar_Click(object sender, EventArgs e)
    {
        try { await CargarAsync(); }
        catch (Exception ex) { MostrarError(ex); }
    }

    private static void MostrarError(Exception ex)
    {
        MessageBox.Show(ex.Message, "Mediciones", MessageBoxButtons.OK, MessageBoxIcon.Warning);
    }
}
