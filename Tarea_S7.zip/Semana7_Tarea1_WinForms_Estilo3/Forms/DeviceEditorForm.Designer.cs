namespace MonitoreoAmbiental.WinForms.Forms;

partial class DeviceEditorForm
{
    private System.ComponentModel.IContainer components = null!;
    private Label lblTitulo = null!;
    private TextBox txtBuscar = null!;
    private Button btnBuscar = null!;
    private DataGridView dgvDispositivos = null!;
    private GroupBox grpDatos = null!;
    private TextBox txtCodigo = null!;
    private TextBox txtNombre = null!;
    private TextBox txtUbicacion = null!;
    private ComboBox cboSensor = null!;
    private CheckBox chkActivo = null!;
    private Button btnNuevo = null!;
    private Button btnGuardar = null!;
    private Button btnEliminar = null!;
    private Label lblRegistros = null!;

    protected override void Dispose(bool disposing)
    {
        if (disposing) components?.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        components = new System.ComponentModel.Container();
        lblTitulo = new Label();
        txtBuscar = new TextBox();
        btnBuscar = new Button();
        dgvDispositivos = new DataGridView();
        grpDatos = new GroupBox();
        txtCodigo = new TextBox();
        txtNombre = new TextBox();
        txtUbicacion = new TextBox();
        cboSensor = new ComboBox();
        chkActivo = new CheckBox();
        btnNuevo = new Button();
        btnGuardar = new Button();
        btnEliminar = new Button();
        lblRegistros = new Label();
        ((System.ComponentModel.ISupportInitialize)dgvDispositivos).BeginInit();
        grpDatos.SuspendLayout();
        SuspendLayout();
        lblTitulo.AutoSize = true;
        lblTitulo.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
        lblTitulo.Location = new Point(24, 20);
        lblTitulo.Text = "Inventario de dispositivos";
        txtBuscar.Location = new Point(28, 71);
        txtBuscar.PlaceholderText = "Buscar dispositivo...";
        txtBuscar.Size = new Size(270, 25);
        btnBuscar.BackColor = Color.FromArgb(0, 126, 112);
        btnBuscar.FlatStyle = FlatStyle.Flat;
        btnBuscar.ForeColor = Color.White;
        btnBuscar.Location = new Point(306, 68);
        btnBuscar.Size = new Size(95, 32);
        btnBuscar.Text = "Buscar";
        btnBuscar.Click += btnBuscar_Click;
        dgvDispositivos.AllowUserToAddRows = false;
        dgvDispositivos.AllowUserToDeleteRows = false;
        dgvDispositivos.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
        dgvDispositivos.AutoGenerateColumns = false;
        dgvDispositivos.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        dgvDispositivos.BackgroundColor = Color.White;
        dgvDispositivos.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Code", HeaderText = "Codigo" });
        dgvDispositivos.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Name", HeaderText = "Nombre" });
        dgvDispositivos.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Location", HeaderText = "Ubicacion" });
        dgvDispositivos.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "SensorType", HeaderText = "Sensor" });
        dgvDispositivos.Columns.Add(new DataGridViewCheckBoxColumn { DataPropertyName = "IsActive", HeaderText = "Activo" });
        dgvDispositivos.Location = new Point(28, 115);
        dgvDispositivos.MultiSelect = false;
        dgvDispositivos.ReadOnly = true;
        dgvDispositivos.RowHeadersVisible = false;
        dgvDispositivos.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        dgvDispositivos.Size = new Size(620, 430);
        dgvDispositivos.SelectionChanged += dgvDispositivos_SelectionChanged;
        grpDatos.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
        grpDatos.Controls.Add(CrearEtiqueta("Codigo", 35));
        grpDatos.Controls.Add(txtCodigo);
        grpDatos.Controls.Add(CrearEtiqueta("Nombre", 100));
        grpDatos.Controls.Add(txtNombre);
        grpDatos.Controls.Add(CrearEtiqueta("Ubicacion", 165));
        grpDatos.Controls.Add(txtUbicacion);
        grpDatos.Controls.Add(CrearEtiqueta("Tipo de sensor", 230));
        grpDatos.Controls.Add(cboSensor);
        grpDatos.Controls.Add(chkActivo);
        grpDatos.Controls.Add(btnNuevo);
        grpDatos.Controls.Add(btnGuardar);
        grpDatos.Controls.Add(btnEliminar);
        grpDatos.Location = new Point(670, 71);
        grpDatos.Size = new Size(350, 474);
        grpDatos.Text = "Datos del dispositivo";
        txtCodigo.Location = new Point(24, 58);
        txtCodigo.Size = new Size(300, 25);
        txtNombre.Location = new Point(24, 123);
        txtNombre.Size = new Size(300, 25);
        txtUbicacion.Location = new Point(24, 188);
        txtUbicacion.Size = new Size(300, 25);
        cboSensor.DropDownStyle = ComboBoxStyle.DropDownList;
        cboSensor.Items.AddRange(new object[] { "DHT11", "DHT22", "SHT31", "Simulado" });
        cboSensor.Location = new Point(24, 253);
        cboSensor.Size = new Size(300, 25);
        chkActivo.AutoSize = true;
        chkActivo.Checked = true;
        chkActivo.Location = new Point(24, 302);
        chkActivo.Text = "Dispositivo activo";
        ConfigurarBoton(btnNuevo, "Nuevo", 24, Color.White, Color.Black);
        ConfigurarBoton(btnGuardar, "Guardar", 118, Color.FromArgb(0, 126, 112), Color.White);
        ConfigurarBoton(btnEliminar, "Eliminar", 220, Color.Firebrick, Color.White);
        btnNuevo.Click += btnNuevo_Click;
        btnGuardar.Click += btnGuardar_Click;
        btnEliminar.Click += btnEliminar_Click;
        btnNuevo.Tag = "Admin,Operador";
        btnGuardar.Tag = "Admin,Operador";
        btnEliminar.Tag = "Admin,Operador";
        lblRegistros.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
        lblRegistros.AutoSize = true;
        lblRegistros.Location = new Point(28, 559);
        lblRegistros.Text = "0 registro(s)";
        AutoScaleMode = AutoScaleMode.Font;
        BackColor = Color.FromArgb(244, 247, 246);
        ClientSize = new Size(1045, 590);
        Controls.Add(lblTitulo);
        Controls.Add(txtBuscar);
        Controls.Add(btnBuscar);
        Controls.Add(dgvDispositivos);
        Controls.Add(grpDatos);
        Controls.Add(lblRegistros);
        Font = new Font("Segoe UI", 10F);
        MinimumSize = new Size(1000, 620);
        Name = "DeviceEditorForm";
        StartPosition = FormStartPosition.CenterParent;
        Text = "Dispositivos";
        Load += DeviceEditorForm_Load;
        ((System.ComponentModel.ISupportInitialize)dgvDispositivos).EndInit();
        grpDatos.ResumeLayout(false);
        grpDatos.PerformLayout();
        ResumeLayout(false);
        PerformLayout();
    }

    private static Label CrearEtiqueta(string text, int top) => new() { AutoSize = true, Location = new Point(24, top), Text = text };

    private static void ConfigurarBoton(Button button, string text, int left, Color backColor, Color foreColor)
    {
        button.BackColor = backColor;
        button.FlatStyle = FlatStyle.Flat;
        button.ForeColor = foreColor;
        button.Location = new Point(left, 365);
        button.Size = new Size(left == 220 ? 104 : 88, 36);
        button.Text = text;
    }
}
