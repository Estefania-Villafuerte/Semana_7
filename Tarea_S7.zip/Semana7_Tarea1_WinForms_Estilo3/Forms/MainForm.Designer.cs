namespace MonitoreoAmbiental.WinForms.Forms;

partial class MainForm
{
    private System.ComponentModel.IContainer components = null!;
    private MenuStrip menuPrincipal = null!;
    private ToolStripMenuItem btnInicio = null!;
    private ToolStripMenuItem btnUsuarios = null!;
    private ToolStripMenuItem btnDispositivos = null!;
    private ToolStripMenuItem btnMediciones = null!;
    private ToolStripMenuItem btnAuditoria = null!;
    private ToolStripMenuItem btnCerrarSesion = null!;
    private Panel panelCabecera = null!;
    private Label lblMarca = null!;
    private Label lblTitulo = null!;
    private Label lblUsuario = null!;
    private Label lblRol = null!;
    private Panel panelContenido = null!;
    private TableLayoutPanel tablaIndicadores = null!;
    private Label lblCantidadUsuarios = null!;
    private Label lblCantidadDispositivos = null!;
    private Label lblCantidadMediciones = null!;
    private Label lblCantidadBloqueos = null!;

    protected override void Dispose(bool disposing)
    {
        if (disposing) components?.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        components = new System.ComponentModel.Container();
        menuPrincipal = new MenuStrip();
        btnInicio = new ToolStripMenuItem();
        btnUsuarios = new ToolStripMenuItem();
        btnDispositivos = new ToolStripMenuItem();
        btnMediciones = new ToolStripMenuItem();
        btnAuditoria = new ToolStripMenuItem();
        btnCerrarSesion = new ToolStripMenuItem();
        panelCabecera = new Panel();
        lblMarca = new Label();
        lblTitulo = new Label();
        lblUsuario = new Label();
        lblRol = new Label();
        panelContenido = new Panel();
        tablaIndicadores = new TableLayoutPanel();
        menuPrincipal.SuspendLayout();
        panelCabecera.SuspendLayout();
        panelContenido.SuspendLayout();
        SuspendLayout();
        menuPrincipal.BackColor = Color.FromArgb(39, 40, 44);
        menuPrincipal.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
        menuPrincipal.ForeColor = Color.White;
        menuPrincipal.Items.AddRange(new ToolStripItem[] { btnInicio, btnUsuarios, btnDispositivos, btnMediciones, btnAuditoria, btnCerrarSesion });
        menuPrincipal.Padding = new Padding(20, 6, 12, 6);
        menuPrincipal.Size = new Size(1160, 43);
        btnInicio.ForeColor = Color.White;
        btnInicio.Text = "Inicio";
        btnUsuarios.ForeColor = Color.White;
        btnUsuarios.Tag = "Admin";
        btnUsuarios.Text = "Usuarios";
        btnDispositivos.ForeColor = Color.White;
        btnDispositivos.Tag = "Admin,Operador,Consulta";
        btnDispositivos.Text = "Dispositivos";
        btnMediciones.ForeColor = Color.White;
        btnMediciones.Tag = "Admin,Operador,Consulta";
        btnMediciones.Text = "Mediciones";
        btnAuditoria.ForeColor = Color.White;
        btnAuditoria.Tag = "Admin";
        btnAuditoria.Text = "Auditoria";
        btnCerrarSesion.Alignment = ToolStripItemAlignment.Right;
        btnCerrarSesion.ForeColor = Color.White;
        btnCerrarSesion.Text = "Cerrar sesion";
        btnInicio.Click += btnInicio_Click;
        btnUsuarios.Click += btnUsuarios_Click;
        btnDispositivos.Click += btnDispositivos_Click;
        btnMediciones.Click += btnMediciones_Click;
        btnAuditoria.Click += btnAuditoria_Click;
        btnCerrarSesion.Click += btnCerrarSesion_Click;
        panelCabecera.BackColor = Color.White;
        panelCabecera.Controls.Add(lblMarca);
        panelCabecera.Controls.Add(lblTitulo);
        panelCabecera.Controls.Add(lblUsuario);
        panelCabecera.Controls.Add(lblRol);
        panelCabecera.Dock = DockStyle.Top;
        panelCabecera.Height = 104;
        lblMarca.AutoSize = true;
        lblMarca.Font = new Font("Segoe UI", 16F, FontStyle.Bold);
        lblMarca.ForeColor = Color.FromArgb(184, 48, 75);
        lblMarca.Location = new Point(30, 22);
        lblMarca.Text = "SENSOR PUYO\nCONTROL AMBIENTAL";
        lblTitulo.AutoSize = true;
        lblTitulo.Font = new Font("Segoe UI", 19F, FontStyle.Bold);
        lblTitulo.Location = new Point(340, 31);
        lblTitulo.Text = "Vista general";
        lblUsuario.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        lblUsuario.Location = new Point(870, 20);
        lblUsuario.Size = new Size(250, 24);
        lblUsuario.TextAlign = ContentAlignment.MiddleRight;
        lblRol.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        lblRol.ForeColor = Color.DimGray;
        lblRol.Location = new Point(870, 48);
        lblRol.Size = new Size(250, 24);
        lblRol.TextAlign = ContentAlignment.MiddleRight;
        panelContenido.BackColor = Color.FromArgb(247, 247, 248);
        panelContenido.Controls.Add(tablaIndicadores);
        panelContenido.Dock = DockStyle.Fill;
        panelContenido.Padding = new Padding(34);
        tablaIndicadores.ColumnCount = 4;
        tablaIndicadores.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
        tablaIndicadores.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
        tablaIndicadores.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
        tablaIndicadores.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
        tablaIndicadores.Controls.Add(CrearIndicador("Usuarios", out lblCantidadUsuarios, Color.FromArgb(0, 132, 131)), 0, 0);
        tablaIndicadores.Controls.Add(CrearIndicador("Dispositivos", out lblCantidadDispositivos, Color.FromArgb(70, 88, 121)), 1, 0);
        tablaIndicadores.Controls.Add(CrearIndicador("Mediciones", out lblCantidadMediciones, Color.FromArgb(224, 160, 40)), 2, 0);
        tablaIndicadores.Controls.Add(CrearIndicador("Bloqueos", out lblCantidadBloqueos, Color.FromArgb(184, 48, 75)), 3, 0);
        tablaIndicadores.Dock = DockStyle.Top;
        tablaIndicadores.Height = 175;
        AutoScaleMode = AutoScaleMode.Font;
        ClientSize = new Size(1160, 700);
        Controls.Add(panelContenido);
        Controls.Add(panelCabecera);
        Controls.Add(menuPrincipal);
        MainMenuStrip = menuPrincipal;
        Font = new Font("Segoe UI", 10F);
        MinimumSize = new Size(1060, 690);
        Name = "MainForm";
        StartPosition = FormStartPosition.CenterScreen;
        Text = "Sensor Puyo - Control ambiental";
        WindowState = FormWindowState.Maximized;
        Load += MainForm_Load;
        menuPrincipal.ResumeLayout(false);
        menuPrincipal.PerformLayout();
        panelCabecera.ResumeLayout(false);
        panelCabecera.PerformLayout();
        panelContenido.ResumeLayout(false);
        ResumeLayout(false);
        PerformLayout();
    }

    private static Panel CrearIndicador(string title, out Label value, Color accent)
    {
        var panel = new Panel { BackColor = Color.White, Dock = DockStyle.Fill, Margin = new Padding(0, 0, 14, 0) };
        panel.Controls.Add(new Panel { BackColor = accent, Dock = DockStyle.Top, Height = 5 });
        value = new Label { AutoSize = true, Font = new Font("Segoe UI", 29F, FontStyle.Bold), Location = new Point(24, 38), Text = "-" };
        panel.Controls.Add(value);
        panel.Controls.Add(new Label { AutoSize = true, ForeColor = Color.DimGray, Location = new Point(26, 112), Text = title });
        return panel;
    }
}
